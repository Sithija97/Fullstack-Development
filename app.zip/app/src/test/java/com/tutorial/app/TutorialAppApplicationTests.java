package com.tutorial.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TutorialAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
